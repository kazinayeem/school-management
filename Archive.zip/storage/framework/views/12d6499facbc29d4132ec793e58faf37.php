<?php $__env->startSection('title', $heading); ?>
<?php $__env->startSection('css'); ?>
<style>
    @page { margin: 22px; }
    .card { width: 256px; height: 200px; border: 1px solid #9ca3af; border-radius: 8px; overflow: hidden; position: relative; background: #fff; }
    .band { height: 40px; color: #fff; padding: 5px 8px; }
    .a { background: #7a1066; } .b { background: #0f766e; }
    .nm { font-size: 12px; font-weight: bold; }
    .small td { font-size: 8px; padding: 1px 4px 1px 0; }
    .cell { padding: 5px; }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('bare'); ?>
<table cellspacing="6">
<?php $__currentLoopData = array_chunk($cards, 1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pair): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
<?php $__currentLoopData = $pair; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<td class="cell">
  <div class="card">
    <div class="band <?php echo e($c['kind'] === 'parent' ? 'b' : 'a'); ?>"><table width="100%"><tr><td width="46"><?php if($school['logo']): ?><img src="<?php echo e($school['logo']); ?>" width="44"><?php endif; ?></td><td><span class="nm"><?php echo e($school['name']); ?></span><br><span style="font-size:7px;letter-spacing:1px"><?php echo e(strtoupper(['student' => 'Student identity card', 'employee' => 'Staff identity card', 'parent' => 'Visiting pass'][$c['kind']])); ?></span></td></tr></table></div>
    <table style="margin:6px 8px"><tr><td width="70"><?php if($c['photo_data']): ?><img src="<?php echo e($c['photo_data']); ?>" width="64" height="80"><?php endif; ?></td>
    <td><span class="nm"><?php echo e($c['name']); ?></span>
    <table class="small"><?php $__currentLoopData = array_slice($c['lines'], 0, 4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><tr><td class="muted"><?php echo e($l[0]); ?></td><td><strong><?php echo e($l[1]); ?></strong></td></tr><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><tr><td class="muted">ID</td><td><strong><?php echo e($c['number']); ?></strong></td></tr></table></td></tr></table>
    <div style="position:absolute;bottom:6px;left:8px"><img src="<?php echo e($c['barcode']); ?>" height="20" width="120"></div>
    <div style="position:absolute;bottom:6px;right:8px;font-size:7px;text-align:right">Session <?php echo e($c['session']); ?><br>Valid until <?php echo e($c['valid_until']); ?></div>
  </div>
</td>
<?php if($backs): ?>
<td class="cell">
  <div class="card"><div style="height:8px" class="<?php echo e($c['kind'] === 'parent' ? 'b' : 'a'); ?>"></div>
  <div style="padding:8px;font-size:8.5px;line-height:1.5">
    <?php $__currentLoopData = $c['extra']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><div><span class="muted"><?php echo e($e[0]); ?></span><br><strong><?php echo e($e[1]); ?></strong></div><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php if($c['phone']): ?><div>Phone <?php echo e($c['phone']); ?></div><?php endif; ?>
    <?php if($c['address']): ?><div><?php echo e($c['address']); ?></div><?php endif; ?>
    <p class="muted" style="font-size:7.5px;border-top:1px solid #e5e7eb;padding-top:4px"><?php echo e($c['kind'] === 'parent' ? 'Show this pass at the gate with a photo ID. It lets you visit the school; it is not an identity card.' : 'This card belongs to the school and must be carried every day. If found, please return it to:'); ?><br><strong><?php echo e($school['name']); ?></strong> <?php echo e($school['address']); ?> <?php echo e($school['phone']); ?></p>
  </div></div>
</td>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pdf.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/mohammadalinayeem/Project & Code/borno-school-managemnt/school/resources/views/pdf/cards.blade.php ENDPATH**/ ?>