<?php $__env->startSection('title', $mode === 'file' ? 'Student file' : 'Academic transcript'); ?>
<?php $__env->startSection('subtitle', $student['name'].' · '.$student['admission_no']); ?>
<?php $__env->startSection('content'); ?>
<table width="100%"><tr>
<td width="80"><?php if($photo): ?><img src="<?php echo e($photo); ?>" width="70" height="86"><?php endif; ?></td>
<td>
<table class="kv">
<tr><td class="muted">Name</td><td><strong><?php echo e($student['name']); ?></strong></td><td class="muted">Admission no.</td><td><?php echo e($student['admission_no']); ?></td></tr>
<tr><td class="muted">Class</td><td><?php echo e($student['class_name']); ?> · <?php echo e($student['section']); ?> · Roll <?php echo e($student['roll_no']); ?></td><td class="muted">Session</td><td><?php echo e($student['session']); ?></td></tr>
<tr><td class="muted">Date of birth</td><td><?php echo e($student['date_of_birth']); ?></td><td class="muted">Gender</td><td><?php echo e($student['gender']); ?></td></tr>
<tr><td class="muted">Guardian</td><td><?php echo e($student['guardian_name']); ?> <?php echo e($student['guardian_mobile']); ?></td><td class="muted">Address</td><td><?php echo e($student['address']); ?></td></tr>
</table></td>
<td align="right"><img src="<?php echo e($barcode); ?>" height="30"></td></tr></table>

<h2>Academic results</h2>
<?php $__empty_1 = true; $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
<p><strong><?php echo e($exam['exam']); ?></strong> — GPA <?php echo e($exam['gpa'] ?? '—'); ?> <?php echo e($exam['grade'] ? '('.$exam['grade'].')' : ''); ?><?php if($exam['class_position']): ?> · Class position <?php echo e($exam['class_position']); ?><?php endif; ?></p>
<table class="grid"><thead><tr><th>Subject</th><th class="num">Marks</th><th class="num">Full</th><th>Grade</th></tr></thead><tbody>
<?php $__currentLoopData = $exam['subjects']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><tr><td><?php echo e($s['subject']); ?></td><td class="num"><?php echo e($s['absent'] ? 'Absent' : $s['marks']); ?></td><td class="num"><?php echo e($s['full_marks']); ?></td><td><?php echo e($s['grade']); ?></td></tr><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<tr><th>Total</th><th class="num"><?php echo e($exam['total']); ?></th><th class="num"><?php echo e($exam['full_total']); ?></th><th></th></tr>
</tbody></table>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><p class="muted">No published results yet.</p><?php endif; ?>

<?php if($mode === 'file'): ?>
<h2>Attendance</h2>
<p>Present <?php echo e($attendance['present']); ?> · Late <?php echo e($attendance['late']); ?> · Absent <?php echo e($attendance['absent']); ?> · Leave <?php echo e($attendance['leave']); ?><?php if($attendance['percent'] !== null): ?> · <?php echo e($attendance['percent']); ?>%<?php endif; ?></p>
<h2>Fees</h2>
<p>Billed <?php echo e(number_format($fees['billed'])); ?> · Paid <?php echo e(number_format($fees['paid'])); ?> · Due <?php echo e(number_format($fees['due'])); ?></p>
<table class="grid"><thead><tr><th>Invoice</th><th>Fee</th><th>Due date</th><th class="num">Payable</th><th class="num">Paid</th><th>Status</th></tr></thead><tbody>
<?php $__currentLoopData = $fees['invoices']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><tr><td><?php echo e($i['invoice_no']); ?></td><td><?php echo e($i['label']); ?></td><td><?php echo e($i['due_on']); ?></td><td class="num"><?php echo e(number_format($i['payable'])); ?></td><td class="num"><?php echo e(number_format($i['paid'])); ?></td><td><?php echo e($i['status']); ?></td></tr><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody></table>
<h2>Certificates</h2>
<?php $__empty_1 = true; $__currentLoopData = $certificates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><div><?php echo e($c['number']); ?> — <?php echo e($c['title']); ?> (<?php echo e($c['issued_on']); ?>)</div><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><p class="muted">None issued.</p><?php endif; ?>
<h2>Library</h2>
<?php $__empty_1 = true; $__currentLoopData = $loans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><div><?php echo e($l['title']); ?> — issued <?php echo e($l['issued_on']); ?> <?php echo e($l['returned_on'] ? 'returned '.$l['returned_on'] : '('.$l['status'].')'); ?></div><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><p class="muted">No loans.</p><?php endif; ?>
<h2>Notes &amp; conduct</h2>
<?php $__empty_1 = true; $__currentLoopData = $notes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><div><strong><?php echo e(ucfirst($n['kind'])); ?></strong> · <?php echo e($n['occurred_on']); ?> · <?php echo e($n['title']); ?> <?php if($n['details']): ?>— <?php echo e($n['details']); ?><?php endif; ?> <?php if($n['action_taken']): ?><em>(<?php echo e($n['action_taken']); ?>)</em><?php endif; ?></div><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><p class="muted">No notes.</p><?php endif; ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pdf.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/mohammadalinayeem/Project & Code/borno-school-managemnt/school/resources/views/pdf/transcript.blade.php ENDPATH**/ ?>