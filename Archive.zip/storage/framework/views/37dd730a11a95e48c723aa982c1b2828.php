<?php $__env->startSection('title', $certificate->title); ?>
<?php $__env->startSection('css'); ?>
<style>
    @page { margin: 0; }
    body { margin: 0; }
    .frame { margin: 22px; border: 3px solid #b8860b; padding: 8px; height: 520px; }
    .inner { border: 1px solid #b8860b; height: 504px; text-align: center; padding: 20px 50px; }
    .title { font-size: 30px; letter-spacing: 4px; color: #8a5a00; margin: 14px 0 6px; font-family: 'DejaVu Serif', serif; }
    .name { font-size: 22px; font-weight: bold; }
    .sig td { text-align: center; font-size: 9px; padding-top: 40px; }
    .line { border-top: 1px solid #555; padding-top: 3px; }
    .madeby { bottom: 8px; }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('bare'); ?>
<div class="frame"><div class="inner">
    <?php if($school['logo']): ?><img src="<?php echo e($school['logo']); ?>" height="42"><?php endif; ?>
    <div style="font-size:15px;font-weight:bold"><?php echo e($school['name']); ?></div>
    <div class="title"><?php echo e(strtoupper($certificate->title)); ?></div>
    <?php if($photo): ?><img src="<?php echo e($photo); ?>" width="64" height="78" style="margin:4px"><?php endif; ?>
    <p style="font-size:13px;line-height:1.7"><?php echo nl2br(e($certificate->body)); ?></p>
    <p class="muted" style="font-size:9px"><?php echo e($certificate->number); ?> · <?php echo e($certificate->issued_on); ?></p>
    <table width="100%" class="sig"><tr><td width="33%"><div class="line">Class teacher</div></td><td><img src="<?php echo e($barcode); ?>" height="26"><div><?php echo e($certificate->number); ?></div></td><td width="33%"><div class="line">Principal</div></td></tr></table>
</div></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pdf.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/mohammadalinayeem/Project & Code/borno-school-managemnt/school/resources/views/pdf/certificate.blade.php ENDPATH**/ ?>