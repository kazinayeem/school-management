<?php $__env->startSection('title', 'Admit cards'); ?>
<?php $__env->startSection('css'); ?><style>@page{margin:20px}.card{border:1.5px solid #111;padding:8px;margin:6px;page-break-inside:avoid}</style><?php $__env->stopSection(); ?>
<?php $__env->startSection('bare'); ?>
<?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="card">
<table width="100%"><tr><td width="64"><?php if($s['photo']): ?><img src="<?php echo e($s['photo']); ?>" width="56" height="70"><?php endif; ?></td>
<td><strong style="font-size:13px"><?php echo e($school['name']); ?></strong><br><?php echo e($exam->name); ?> — <strong>ADMIT CARD</strong><br>
<span class="muted">Name</span> <strong><?php echo e($s['name']); ?></strong> · <span class="muted">Class</span> <?php echo e($class); ?> <?php echo e($s['section']); ?> · <span class="muted">Roll</span> <?php echo e($s['roll_no']); ?> · <span class="muted">ID</span> <?php echo e($s['admission_no']); ?></td>
<td align="right"><img src="<?php echo e($s['barcode']); ?>" height="26"></td></tr></table>
<table class="grid" style="margin-top:6px"><thead><tr><th>Date</th><th>Subject</th><th>Time</th><th>Room</th></tr></thead><tbody>
<?php $__currentLoopData = $schedule; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><tr><td><?php echo e($r['date']); ?></td><td><?php echo e($r['subject']); ?></td><td><?php echo e($r['time']); ?></td><td><?php echo e($r['room']); ?></td></tr><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody></table>
<p class="muted" style="font-size:8px">Bring this card to every exam. Arrive 15 minutes early. Signature of principal: ____________________</p>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pdf.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/mohammadalinayeem/Project & Code/borno-school-managemnt/school/resources/views/pdf/admit.blade.php ENDPATH**/ ?>