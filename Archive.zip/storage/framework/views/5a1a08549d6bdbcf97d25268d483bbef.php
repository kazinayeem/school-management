<?php $__env->startSection('title', 'Payslip · '.$slip->month); ?>
<?php $__env->startSection('subtitle', $me['name']); ?>
<?php $__env->startSection('content'); ?>
<table class="kv"><tr><td class="muted">Name</td><td><strong><?php echo e($me['name']); ?></strong></td><td class="muted">Employee no.</td><td><?php echo e($me['employee_no']); ?></td></tr>
<tr><td class="muted">Designation</td><td><?php echo e($me['designation']); ?></td><td class="muted">Paid on</td><td><?php echo e($slip->paid_on); ?></td></tr></table>
<table class="grid" style="margin-top:12px"><tbody>
<tr><td>Basic salary</td><td class="num"><?php echo e($currency); ?> <?php echo e(number_format($slip->basic)); ?></td></tr>
<tr><td>Allowances</td><td class="num"><?php echo e($currency); ?> <?php echo e(number_format($slip->earnings)); ?></td></tr>
<tr><td>Deductions</td><td class="num">− <?php echo e($currency); ?> <?php echo e(number_format($slip->deductions)); ?></td></tr>
<tr><th>Net pay</th><th class="num" style="font-size:13px"><?php echo e($currency); ?> <?php echo e(number_format($slip->net)); ?></th></tr></tbody></table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pdf.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/mohammadalinayeem/Project & Code/borno-school-managemnt/school/resources/views/pdf/payslip.blade.php ENDPATH**/ ?>