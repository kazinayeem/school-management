<?php $__env->startSection('title', $title); ?>
<?php $__env->startSection('subtitle', $subtitle ?? ''); ?>
<?php $__env->startSection('content'); ?>
<?php if(!empty($filters)): ?><p class="muted"><?php echo e($filters); ?></p><?php endif; ?>
<?php if(!empty($summary)): ?>
<table class="kv"><tr><?php $__currentLoopData = $summary; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><td><strong style="font-size:14px"><?php echo e(is_numeric($s['value']) ? number_format($s['value']) : $s['value']); ?></strong><br><span class="muted"><?php echo e($s['label']); ?></span></td><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></tr></table>
<?php endif; ?>
<?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if(!empty($section['title'])): ?><h2><?php echo e($section['title']); ?></h2><?php endif; ?>
<table class="grid">
<thead><tr><?php $__currentLoopData = $section['columns']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><th class="<?php echo e(!empty($c['num']) || !empty($c['money']) ? 'num' : ''); ?>"><?php echo e($c['label']); ?></th><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></tr></thead>
<tbody>
<?php $__empty_1 = true; $__currentLoopData = $section['rows']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
<tr><?php $__currentLoopData = $section['columns']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php ($v = $row[$c['key']] ?? ''); ?><td class="<?php echo e(!empty($c['num']) || !empty($c['money']) ? 'num' : ''); ?>"><?php echo e(!empty($c['money']) && is_numeric($v) ? number_format($v) : $v); ?></td><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
<tr><td colspan="<?php echo e(count($section['columns'])); ?>" class="muted">No records.</td></tr>
<?php endif; ?>
<?php if(!empty($section['footer'])): ?>
<tr><?php $__currentLoopData = $section['columns']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php ($v = $section['footer'][$c['key']] ?? ''); ?><th class="<?php echo e(!empty($c['num']) || !empty($c['money']) ? 'num' : ''); ?>"><?php echo e(!empty($c['money']) && is_numeric($v) ? number_format($v) : $v); ?></th><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></tr>
<?php endif; ?>
</tbody></table>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pdf.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/mohammadalinayeem/Project & Code/borno-school-managemnt/school/resources/views/pdf/table.blade.php ENDPATH**/ ?>