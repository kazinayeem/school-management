<?php $__env->startSection('title', 'Fee receipt'); ?>
<?php $__env->startSection('subtitle', $payment->receipt_no); ?>
<?php $__env->startSection('content'); ?>
<table class="kv"><tr><td class="muted">Student</td><td><strong><?php echo e($student->name); ?></strong></td><td class="muted">Class</td><td><?php echo e($student->class_name); ?> <?php echo e($student->section); ?> · Roll <?php echo e($student->roll_no); ?></td></tr>
<tr><td class="muted">Admission no.</td><td><?php echo e($student->admission_no); ?></td><td class="muted">Date</td><td><?php echo e($payment->paid_on); ?></td></tr>
<tr><td class="muted">Method</td><td><?php echo e($payment->method); ?></td><td class="muted">Receipt</td><td><?php echo e($payment->receipt_no); ?></td></tr></table>
<table class="grid" style="margin-top:12px"><tbody>
<tr><td>Amount paid</td><td class="num"><?php echo e(number_format($payment->amount)); ?></td></tr>
<?php if($payment->late_fee > 0): ?><tr><td>Late fee</td><td class="num"><?php echo e(number_format($payment->late_fee)); ?></td></tr><?php endif; ?>
<tr><th>Total received</th><th class="num"><?php echo e(number_format($payment->amount + $payment->late_fee)); ?></th></tr></tbody></table>
<p class="muted">This is a computer-generated receipt.</p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pdf.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/mohammadalinayeem/Project & Code/borno-school-managemnt/school/resources/views/pdf/receipt.blade.php ENDPATH**/ ?>